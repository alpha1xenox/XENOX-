<p align="center">
  <img src="https://telegra.ph/file/00ed6f993e410f834c891.jpg" alt="animated" width="300" height="300" />
</p>

  <h2 align="center">• 💃 𝙌𝙐𝙀𝙀𝙉 𝙀𝙇𝙄𝙎𝘼 𝘽𝙊𝙏 💃 •<br></h2>
  
  
<h6 align= "center"> 
Queen Elisa Whatsapp bot made by dark maker base on cheems can you use queen elisa with amazing fetures
</h6>

## 

<p align="left">
<a href="http://www.queenelisa.42web.io"><img align="center" src="https://telegra.ph/file/8b7c4a9bbaae67b1b2e0e.png" alt="VISIT QUEEN ELISA WEBSITE" height="35" width="150" /></a>
</p align="left">

## 



`DEPLOY QUEEN ELISA`
 
**1.** _Fork Queen Elisa Repository._

<p align="left">
<a href="https://github.com/DarkMakerofc/Queen-Elisa-MD-V2/fork"><img align="center" src="https://telegra.ph/file/3514997e86c4bb12d8f67.png" alt="Fork and deploy" height="35" width="155" /></a>


**2** _Scan Qr code using your whatsapp (install)._


### [`SCAN QR CODE`](https://replit.com/@MRNima/QUEEN-ELISA-V2-MD-WHATSAPP-SCANER?v=1?outputonly=1&lite=1#index.js)



**3** _Uplode **session.json** File Your forked repository._


**4**  _[Make your deploy link `Video`]() and deploy your bot using link Fill heroku_

     https://heroku.com/deploy?template=

##  
##  
       『 𝙷𝙴𝙻𝙿𝙴𝚁𝚂 』
          𝚂𝙻 𝚁𝙴𝙰𝙻 𝚃𝙴𝙲𝙷
          𝚂𝙰𝙽𝚄𝚆𝙰
          𝙳𝙰𝚁𝙺 𝙰𝙻𝙿𝙷𝙰

##
## 

#### 『 𝚀𝚄𝙴𝙴𝙽 𝙴𝙻𝙸𝚂𝙰 𝙿𝚄𝙱𝙻𝙸𝙲 𝙶𝚁𝙾𝚄𝙿 』
[`𝙹𝙾𝙸𝙽 𝙽𝙾𝚆`]()

#### 『 𝙷𝙾𝚆 𝚃𝙾 𝙼𝙰𝙺𝙴 𝙱𝙾𝚃 [`𝚆𝙰𝚃𝙲𝙷 𝚅𝙸𝙳𝙴𝙾`]() 』

`THANKS FRO USING QUEEN ELISA 💞`
